const { resolve } = require('path');
const webpack = require('webpack');
//const HtmlWebpackPlugin = require('html-webpack-plugin');


const { NODE_ENV = 'production' } = process.env;

const HASH_TYPE = NODE_ENV === 'production' ? 'chunkhash' : 'hash';

const onlyInProd = onlyIn('production');

const ROOT = resolve(__dirname);
const APP = resolve(ROOT, 'src');
const PUB = resolve(ROOT, 'public');
 
module.exports = {
  entry: {
	app: [
	  resolve(APP, 'index.js'),
	  resolve(PUB, 'index.html'),
	].filter(Boolean),
  },
  output: {
    filename: '[name].[${HASH_TYPE}].js',
    path: resolve(ROOT, 'dist', 'client'),
    publicPath: '/',
  },
  module: {
    rules: [
      {
  	test: /\.js$/,
	loader: "babel-loader",
	exclude: "/node_modules/",
	options: {
          presets: [],
        },
      },
    ],
  }/*,
  plugins: [
        new HtmlWebpackPlugin({
            template: resolve(PUB, 'index.html'),//'./public/index.html',
        })
    ]*/
};