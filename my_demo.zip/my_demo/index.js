var http = require('http');
const path = require('path');
var express = require('express');
var bodyParser = require('body-parser');
var webpack = require('webpack');
var webpackDevMiddleware = require('webpack-dev-middleware');
var webpackHotMiddleware = require('webpack-hot-middleware');
var { resolve } = require('path');
var historyFallback = require('connect-history-api-fallback');

const ROOT = resolve(__dirname);

var webpackConfig =  require(ROOT, 'webpack.config.js');
var users = require(ROOT, 'users.json');


const { NODE_ENV = 'development', PORT = 3000 } = process.env;

const app = express();
const SRV = resolve(ROOT);



if (NODE_ENV === 'production') {
  const FE_DIR = resolve(__dirname, 'src', 'fe');
	console.log(FE_DIR);
  app.use(express.static(FE_DIR));

  app.get('/*', (req, res) => {
    res.sendFile(resolve(FE_DIR, 'index.html'));
  });
} else {
  const compiler = webpack(webpackConfig);

  app.use(webpackDevMiddleware(compiler, {
    stats: { colors: true },
  }));
  app.use(webpackHotMiddleware(compiler));
}

const server = http.createServer(app);

server.listen(PORT, () => {
  console.log(`The server is running at http://localhost:${PORT}`);
});
