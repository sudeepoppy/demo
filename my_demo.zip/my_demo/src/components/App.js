import React from 'react';
import Cms from './Cms';

const App = () => App('<Cms />');

export default App;
