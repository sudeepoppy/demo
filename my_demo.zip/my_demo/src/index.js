//import html from "./file.html";
import ReactDOM from 'react-dom';


ReactDOM.render(
    "<h1>Hello World</h1>",
  document.getElementById('root')
);