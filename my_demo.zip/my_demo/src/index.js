import React from 'react';

import ReactDOM from '@hot-loader/react-dom';
//import 'semantic-ui-css/semantic.min.css';
import { AppContainer } from 'react-hot-loader';

import App from './components/App';
 var  root  =  document.getElementById('app-container');
const renderApp = () => {
  ReactDOM.render(
    AppContainer('<App />'),
    root 
  );
};

renderApp();

// Hot module reloading
if (module.hot) {
  module.hot.accept('./components/App', renderApp);
}

