const express = require('express');
const app = express(),fs = require("graceful-fs"),
      bodyParser = require("body-parser");
      port = 3080;

const users = [];

//html/mytext.txt
app.get('/', function (req, res) {
//   writeToFilexx(new File(process.cwd()+"/my-app/dist/angular-nodejs-example/html/mytext.txt"), 'heY');
//   var fileread = new FileReader();


        fs.writeFile(process.cwd()+"/my-app/dist/angular-nodejs-example/html/rep.htm", "mytext.txt \n sample.htm \n simple.json");

     res.sendFile(process.cwd()+"/my-app/dist/angular-nodejs-example/start.html");
     
/*
    setTimeout(function(){
	fs.writeFile(process.cwd()+"/my-app/dist/angular-nodejs-example/html/rep.htm", "mytext.txt\nsample.htm\nsimple.json");
    }, 1000);
*/  

/*
    var filewrite = new FileWriter(process.cwd()+"/my-app/dist/angular-nodejs-example/html/mytext.txt");
	  filewrite.readAsText(file_to_read);
*/


})



app.use(bodyParser.json());

app.use(express.static(process.cwd()+"/my-app/dist/angular-nodejs-example/"));

app.get('/api/users', (req, res) => {
  res.json(users);
});

app.post('/api/user', (req, res) => {
  const user = req.body.user;
  users.push(user);
  res.json("user addedd");
});

/*
app.get('/', (req,res) => {
  
//     fs.writeFile(process.cwd()+"/my-app/dist/angular-nodejs-example/html/rep.htm", "mytext.txt \n sample.htm \n simple.json");
     res.sendFile(process.cwd()+"/my-app/dist/angular-nodejs-example/index.html")

});
*/
/*
app.get('/', (req,res) => {
  res.sendFile(process.cwd()+"/my-app/dist/angular-nodejs-example/html/mytext.txt")
});*/

app.listen(port, () => {
    console.log(`Server listening on the port::${port}`);
});
