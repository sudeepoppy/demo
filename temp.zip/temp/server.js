const express = require('express');
const app = express(),fs = require("fs"),
      bodyParser = require("body-parser");
      port = 3080;


//my-app/html/mytext.txt
app.get('/', function (req, res) {
 
  fs.writeFile(process.cwd()+"/my-app/html/rep.htm","", function(err) {       

  });

  fs.readdir(process.cwd()+"/my-app/html/", function(err, filenames) {

	filenames.forEach(function(filename) {

          fs.appendFileSync(process.cwd()+"/my-app/html/rep.htm",filename + ",", function(err) {       

	  });

  	});

  });

  fs.readdir(process.cwd()+"/my-app/css/", function(err, filenames) {

	filenames.forEach(function(filename) {

          fs.appendFileSync(process.cwd()+"/my-app/html/rep.htm",filename + ",", function(err) {       

	  });

  	});

  });

    

     res.sendFile(process.cwd()+"/my-app/start.html");

});



app.use(bodyParser.json());

app.use(express.static(process.cwd()+"/my-app/"));

app.listen(port, () => {
    console.log(`Server listening on the port::${port}`);
});
