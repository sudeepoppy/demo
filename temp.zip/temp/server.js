const express = require('express');
const app = express(),fs = require("fs"),
      bodyParser = require("body-parser");
      port = 3080;


//my-app/html/mytext.txt
app.get('/', function (req, res) {

  var  names = "";

  fs.readdir(process.cwd()+"/my-app/html/", function(err, filenames) {

	filenames.forEach(function(filename) {

		names  +=  filename.trim() + ",";
  	});

  });


  fs.readdir(process.cwd()+"/my-app/css/", function(err, filenames) {

	filenames.forEach(function(filename) {
		names  +=  filename.trim() + ",";
  	});

	fs.writeFile(process.cwd()+"/my-app/html/Master.ini", names, function(err) {       
	
        });


        });

    

     res.sendFile(process.cwd()+"/my-app/start.html");

});



app.use(bodyParser.json());

app.use(express.static(process.cwd()+"/my-app/"));

app.listen(port, () => {
    console.log(`Server listening on the port::${port}`);
});
