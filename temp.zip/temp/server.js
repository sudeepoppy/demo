const express = require('express');
const app = express(),fs = require("graceful-fs"),
      bodyParser = require("body-parser");
      port = 3080;


//my-app/html/mytext.txt
app.get('/', function (req, res) {

        fs.writeFile(process.cwd()+"/my-app/html/rep.htm", "mytext.txt sample.htm simple.json");

     res.sendFile(process.cwd()+"/my-app/start.html");

})



app.use(bodyParser.json());

app.use(express.static(process.cwd()+"/my-app/"));

app.listen(port, () => {
    console.log(`Server listening on the port::${port}`);
});
